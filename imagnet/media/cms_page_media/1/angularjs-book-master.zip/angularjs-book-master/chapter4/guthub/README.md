GutHub
======
A recipe database in AngularJS and MongoLab.